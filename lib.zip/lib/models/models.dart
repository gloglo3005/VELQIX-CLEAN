// ============================================================
// MODELS
// ============================================================

enum PropertyType { immobilier, mobilier }
enum ListingType { vente, location, les_deux }
enum PropertyCategory {
  maison, appartement, terrain, bureau, entrepot,
  voiture, moto, camion, equipement, autre
}

class UserModel {
  final String id;
  final String nom;
  final String prenom;
  final String email;
  final String telephone;
  final String? avatarUrl;
  final bool isVerified;
  final double rating;
  final int totalAvis;
  final DateTime createdAt;
  final String role; // 'proprietaire', 'client', 'admin'
  final bool isPremium;
  final String? countryCode; // Code ISO 2 lettres ex: 'TG', 'FR', 'US'
  final String? countryName; // Nom du pays ex: 'Togo', 'France'
  final String accountType; // 'personal' | 'business'
  final String? nomEntreprise;
  final String? typeActivite;

  UserModel({
    required this.id,
    required this.nom,
    required this.prenom,
    required this.email,
    required this.telephone,
    this.avatarUrl,
    this.isVerified = false,
    this.rating = 0.0,
    this.totalAvis = 0,
    required this.createdAt,
    this.role = 'client',
    this.isPremium = false,
    this.countryCode,
    this.countryName,
    this.accountType = 'personal',
    this.nomEntreprise,
    this.typeActivite,
  });

  String get fullName => '$prenom $nom'.trim();
  String get initials {
    final p = prenom.trim();
    final n = nom.trim();
    if (p.isEmpty && n.isEmpty) return '?';
    if (p.isEmpty) return n[0].toUpperCase();
    if (n.isEmpty) return p[0].toUpperCase();
    return '${p[0]}${n[0]}'.toUpperCase();
  }

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'],
    nom: json['nom'],
    prenom: json['prenom'],
    email: json['email'],
    telephone: json['telephone'],
    avatarUrl: json['avatarUrl'],
    isVerified: json['isVerified'] ?? false,
    rating: (json['rating'] ?? 0.0).toDouble(),
    totalAvis: json['totalAvis'] ?? 0,
    createdAt: DateTime.parse(json['createdAt']),
    role: json['role'] ?? 'client',
    isPremium: json['isPremium'] ?? false,
    countryCode: json['countryCode'],
    countryName: json['countryName'],
    accountType: json['accountType'] ?? 'personal',
    nomEntreprise: json['nomEntreprise'],
    typeActivite: json['typeActivite'],
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'nom': nom, 'prenom': prenom, 'email': email,
    'telephone': telephone, 'avatarUrl': avatarUrl, 'isVerified': isVerified,
    'rating': rating, 'totalAvis': totalAvis, 'createdAt': createdAt.toIso8601String(),
    'role': role, 'isPremium': isPremium,
    'countryCode': countryCode, 'countryName': countryName,
    'accountType': accountType, 'nomEntreprise': nomEntreprise, 'typeActivite': typeActivite,
  };
}

class PropertyModel {
  final String id;
  final String titre;
  final String description;
  final PropertyType type;
  final ListingType listingType;
  final PropertyCategory categorie;
  final double prix;
  final String? prixParJour;
  final List<String> images;
  final AddressModel adresse;
  final UserModel proprietaire;
  final List<String> caracteristiques;
  final double rating;
  final int totalAvis;
  final bool isAvailable;
  final bool isFeatured;
  final DateTime createdAt;
  final int vues;
  final String? surface; // m²
  final int? nombrePieces;
  final int? annee;
  // 'en_attente' | 'approuve' | 'rejete'
  final String status;
  // Multilingual translations: {'en': '...', 'es': '...', 'pt': '...', 'de': '...', 'ar': '...'}
  final Map<String, String>? titreTranslations;
  final Map<String, String>? descriptionTranslations;
  final Map<String, List<String>>? caracteristiquesTranslations;

  PropertyModel({
    required this.id,
    required this.titre,
    required this.description,
    required this.type,
    required this.listingType,
    required this.categorie,
    required this.prix,
    this.prixParJour,
    required this.images,
    required this.adresse,
    required this.proprietaire,
    this.caracteristiques = const [],
    this.rating = 0.0,
    this.totalAvis = 0,
    this.isAvailable = true,
    this.isFeatured = false,
    required this.createdAt,
    this.vues = 0,
    this.surface,
    this.nombrePieces,
    this.annee,
    this.status = 'approuve', // Les anciens biens sont approuvés par défaut
    this.titreTranslations,
    this.descriptionTranslations,
    this.caracteristiquesTranslations,
  });

  /// Lien de partage vers la page du bien (deep link web)
  String get shareUrl => 'https://libimmo.tg/bien/$id';

  /// Texte de partage incluant le lien retour
  String get shareText {
    final montant = prix % 1 == 0
        ? prix.toInt().toString().replaceAllMapped(
            RegExp(r'(\d)(?=(\d{3})+$)'), (m) => '${m[1]} ')
        : prix.toString();
    return '🏠 $titre\n'
        '📍 ${adresse.full}\n'
        '💰 $montant FCFA\n'
        '🔗 Disponible sur LibImmo\n'
        '$shareUrl';
  }

  String get typeLabel => type == PropertyType.immobilier ? 'Immobilier' : 'Mobilier';
  String get listingLabel {
    switch (listingType) {
      case ListingType.vente: return 'Vente';
      case ListingType.location: return 'Location';
      case ListingType.les_deux: return 'Vente / Location';
    }
  }

  String get categorieLabel {
    const labels = {
      PropertyCategory.maison: 'Maison',
      PropertyCategory.appartement: 'Appartement',
      PropertyCategory.terrain: 'Terrain',
      PropertyCategory.bureau: 'Bureau',
      PropertyCategory.entrepot: 'Entrepôt',
      PropertyCategory.voiture: 'Voiture',
      PropertyCategory.moto: 'Moto',
      PropertyCategory.camion: 'Camion',
      PropertyCategory.equipement: 'Équipement',
      PropertyCategory.autre: 'Autre',
    };
    return labels[categorie] ?? 'Autre';
  }

  String get firstImage => images.isNotEmpty ? images.first : '';

  /// Returns localized title (falls back to French)
  String getLocalizedTitre(String lang) =>
      titreTranslations?[lang] ?? titreTranslations?['en'] ?? titre;

  /// Returns localized description (falls back to French)
  String getLocalizedDescription(String lang) =>
      descriptionTranslations?[lang] ?? descriptionTranslations?['en'] ?? description;

  /// Returns localized caracteristiques (falls back to French list)
  List<String> getLocalizedCaracteristiques(String lang) =>
      caracteristiquesTranslations?[lang] ?? caracteristiquesTranslations?['en'] ?? caracteristiques;
}

class AddressModel {
  final String rue;
  final String ville;
  final String pays;
  final double? latitude;
  final double? longitude;

  AddressModel({
    required this.rue,
    required this.ville,
    required this.pays,
    this.latitude,
    this.longitude,
  });

  String get full => '$rue, $ville, $pays';
  String get short => '$ville, $pays';
}

class TransactionModel {
  final String id;
  final PropertyModel property;
  final UserModel client;
  final String type; // 'achat', 'location'
  final double montant;
  final String statut; // 'en_attente', 'confirme', 'annule', 'termine'
  final DateTime dateDebut;
  final DateTime? dateFin;
  final String methode; // 'mobile_money', 'carte', 'paypal'
  final DateTime createdAt;

  TransactionModel({
    required this.id,
    required this.property,
    required this.client,
    required this.type,
    required this.montant,
    required this.statut,
    required this.dateDebut,
    this.dateFin,
    required this.methode,
    required this.createdAt,
  });

  String get statutLabel {
    const labels = {
      'en_attente': 'En attente',
      'confirme': 'Confirmé',
      'annule': 'Annulé',
      'termine': 'Terminé',
    };
    return labels[statut] ?? statut;
  }
}

class MessageModel {
  final String id;
  final String senderId;
  final String receiverId;
  final String content;
  final DateTime sentAt;
  final bool isRead;
  final String? propertyId;

  MessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.content,
    required this.sentAt,
    this.isRead = false,
    this.propertyId,
  });
}

class AvisModel {
  final String id;
  final UserModel auteur;
  final String cible; // propertyId or userId
  final double note;
  final String commentaire;
  final DateTime createdAt;

  AvisModel({
    required this.id,
    required this.auteur,
    required this.cible,
    required this.note,
    required this.commentaire,
    required this.createdAt,
  });
}
