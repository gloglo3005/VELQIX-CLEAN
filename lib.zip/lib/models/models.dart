// ============================================================
// MODELS
// ============================================================

enum PropertyType { immobilier, mobilier }
enum ListingType { vente, location, les_deux }
enum PropertyCategory {
  // Cahier des charges §8.1 : chambres, maisons, appartements, studios,
  // terrains, locaux commerciaux, bureaux.
  chambre, studio, maison, appartement, terrain, localCommercial, bureau,
  // Catégories historiques : toujours lisibles, mais plus proposées à la
  // publication (le lancement se concentre sur l'immobilier — §4.2).
  hotel, entrepot,
  voiture, moto, camion, equipement, autre
}

extension PropertyCategoryApi on PropertyCategory {
  /// Valeur échangée avec l'API (snake_case, comme l'enum Prisma).
  String get apiValue => this == PropertyCategory.localCommercial ? 'local_commercial' : name;
}

/// États de disponibilité affichés à l'utilisateur (cahier des charges §7.2).
/// Une annonce publiée n'est JAMAIS assimilée à un bien disponible (§7.1).
enum AvailabilityState {
  declared,           // Déclaré disponible (par l'annonceur, à une date)
  confirmedRecently,  // Disponibilité confirmée récemment
  pending,            // Confirmation en attente
  toReconfirm,        // Disponibilité à reconfirmer (information ancienne)
  unavailable,        // Indisponible (loué, vendu…)
  suspended,          // Suspendu pour vérification
  archived,           // Archivé
}

class UserModel {
  final String id;
  final String nom;
  final String prenom;
  final String email;
  final String telephone;
  final String? avatarUrl;
  final bool isVerified;
  final bool isActive; // false = compte suspendu par un administrateur
  final bool mustChangePassword; // true après une réinitialisation par un admin
  final double rating;
  final int totalAvis;
  final DateTime createdAt;
  final String role; // 'client', 'proprietaire', 'admin', 'demarcheur', 'agent_entretien'
  final bool isPremium;
  final String? countryCode; // Code ISO 2 lettres ex: 'TG', 'FR', 'US'
  final String? countryName; // Nom du pays ex: 'Togo', 'France'
  final String accountType; // 'personal' | 'business'
  final String? nomEntreprise;
  final String? typeActivite;
  final int followersCount;
  final int followingCount;
  final bool isFollowedByMe;

  UserModel({
    required this.id,
    required this.nom,
    required this.prenom,
    required this.email,
    required this.telephone,
    this.avatarUrl,
    this.isVerified = false,
    this.isActive = true,
    this.mustChangePassword = false,
    this.rating = 0.0,
    this.totalAvis = 0,
    required this.createdAt,
    this.role = 'client',
    this.isPremium = false,
    this.countryCode,
    this.countryName,
    this.accountType = 'personal',
    this.nomEntreprise,
    this.typeActivite,
    this.followersCount = 0,
    this.followingCount = 0,
    this.isFollowedByMe = false,
  });

  // ── Comptes créés uniquement par l'équipe VelQix / l'administrateur ──────
  bool get isDemarcheur => role == 'demarcheur';
  bool get isAgentEntretien => role == 'agent_entretien';
  bool get isStaff => isDemarcheur || isAgentEntretien;
  String get roleLabel {
    switch (role) {
      case 'demarcheur':      return 'Démarcheur';
      case 'agent_entretien': return "Agent d'entretien";
      case 'admin':           return 'Administrateur';
      case 'proprietaire':    return 'Propriétaire';
      default:                return 'Client';
    }
  }

  String get fullName {
  return "$prenom $nom".trim();
}

String get initials {
  String p = prenom.isNotEmpty ? prenom[0] : "";
  String n = nom.isNotEmpty ? nom[0] : "";
  return (p + n).toUpperCase();
}

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'],
    nom: json['nom'],
    prenom: json['prenom'],
    // ⚠️ Certains endpoints (ex: GET /api/users recherche) n'exposent
    // volontairement pas email/téléphone pour la confidentialité — on
    // retombe sur '' plutôt que de planter (null → String non-nullable).
    email: json['email'] ?? '',
    telephone: json['telephone'] ?? '',
    avatarUrl: json['avatarUrl'],
    isVerified: json['isVerified'] ?? false,
    isActive: json['isActive'] ?? true,
    mustChangePassword: json['mustChangePassword'] ?? false,
    rating: (json['rating'] ?? 0.0).toDouble(),
    totalAvis: json['totalAvis'] ?? 0,
    createdAt: DateTime.parse(json['createdAt']),
    role: json['role'] ?? 'client',
    isPremium: json['isPremium'] ?? false,
    countryCode: json['countryCode'],
    countryName: json['countryName'],
    accountType: json['accountType'] ?? 'personal',
    nomEntreprise: json['nomEntreprise'],
    typeActivite: json['typeActivite'],
    // Présents uniquement sur GET /api/users/:id — absents ailleurs (ex.
    // proprietaire embarqué dans une annonce), d'où les valeurs par défaut.
    followersCount: json['followersCount'] ?? 0,
    followingCount: json['followingCount'] ?? 0,
    isFollowedByMe: json['isFollowedByMe'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'nom': nom, 'prenom': prenom, 'email': email,
    'telephone': telephone, 'avatarUrl': avatarUrl, 'isVerified': isVerified,
    'rating': rating, 'totalAvis': totalAvis, 'createdAt': createdAt.toIso8601String(),
    'role': role, 'isPremium': isPremium,
    'countryCode': countryCode, 'countryName': countryName,
    'accountType': accountType, 'nomEntreprise': nomEntreprise, 'typeActivite': typeActivite,
  };
}

class PropertyModel {
  final String id;
  final String titre;
  final String description;
  final PropertyType type;
  final ListingType listingType;
  final PropertyCategory categorie;
  final double prix;
  final String? prixParJour;
  final List<String> images;
  final String? videoUrl; // vidéo de l'annonce (Cloudinary), optionnelle
  final AddressModel adresse;
  final UserModel proprietaire;
  final List<String> caracteristiques;
  final double rating;
  final int totalAvis;
  final bool isAvailable;
  final bool isFeatured;
  final DateTime createdAt;
  final int vues;
  final String? surface; // m²
  final int? nombrePieces;
  final int? annee;
  // 'en_attente' | 'approuve' | 'rejete'
  final String status;
  // Multilingual translations: {'en': '...', 'es': '...', 'pt': '...', 'de': '...', 'ar': '...'}
  final Map<String, String>? titreTranslations;
  final Map<String, String>? descriptionTranslations;
  final Map<String, List<String>>? caracteristiquesTranslations;
  final DateTime? updatedAt;

  // ── Disponibilité (cahier des charges §7) ────────────────────────────────
  // Valeur brute renvoyée par l'API (voir BACKEND_CHANGES.md) : 'available',
  // 'pending', 'unavailable' (loué / vendu), 'suspended', 'archived'.
  final String? availabilityStatus;
  // Date de la dernière confirmation de disponibilité par l'annonceur.
  final DateTime? lastConfirmedAt;

  // ── Vérification terrain ─────────────────────────────────────────────────
  // Un bien est « vérifié sur le terrain » uniquement si un agent VelQix s'est
  // rendu sur place (mission de vérification validée). Un paiement (Premium,
  // mise en avant…) ne donne JAMAIS ce statut (cahier des charges §10.3).
  final bool fieldVerified;            // vérifié sur place par un démarcheur
  final DateTime? fieldVerifiedAt;
  final String? fieldVerifiedByName;   // nom du démarcheur
  final bool verificationRequested;    // le propriétaire a demandé la vérification

  PropertyModel({
    required this.id,
    required this.titre,
    required this.description,
    required this.type,
    required this.listingType,
    required this.categorie,
    required this.prix,
    this.prixParJour,
    required this.images,
    this.videoUrl,
    required this.adresse,
    required this.proprietaire,
    this.caracteristiques = const [],
    this.rating = 0.0,
    this.totalAvis = 0,
    this.isAvailable = true,
    this.isFeatured = false,
    required this.createdAt,
    this.vues = 0,
    this.surface,
    this.nombrePieces,
    this.annee,
    this.status = 'approuve', // Les anciens biens sont approuvés par défaut
    this.titreTranslations,
    this.descriptionTranslations,
    this.caracteristiquesTranslations,
    this.updatedAt,
    this.availabilityStatus,
    this.lastConfirmedAt,
    this.fieldVerified = false,
    this.fieldVerifiedAt,
    this.fieldVerifiedByName,
    this.verificationRequested = false,
  });

  /// Vérifié sur le terrain par un agent VelQix. Le statut Premium du
  /// propriétaire n'entre PAS dans ce calcul (cahier des charges §10.3 :
  /// « le paiement ne doit jamais permettre d'afficher un bien comme vérifié »).
  /// Le nom est conservé pour ne pas casser les écrans existants.
  bool get isVelqixApproved => fieldVerified;

  /// Durée (en jours) pendant laquelle une information est dite « récente ».
  /// Paramètre à rendre configurable côté admin (§7.2 : ~7 jours à tester).
  static int freshnessDays = 7;

  /// Date de référence de l'information de disponibilité affichée.
  DateTime get availabilityDate => lastConfirmedAt ?? updatedAt ?? createdAt;

  /// État de disponibilité calculé. Sans confirmation explicite de l'annonceur,
  /// on affiche « Déclaré disponible » — jamais « confirmé ».
  AvailabilityState get availabilityState {
    switch ((availabilityStatus ?? '').toLowerCase()) {
      case 'unavailable': case 'indisponible': case 'rented': case 'loue':
      case 'sold': case 'vendu':
        return AvailabilityState.unavailable;
      case 'suspended': case 'suspendu':
        return AvailabilityState.suspended;
      case 'archived': case 'archive':
        return AvailabilityState.archived;
      case 'pending': case 'confirmation_pending':
        return AvailabilityState.pending;
    }
    if (!isAvailable) return AvailabilityState.unavailable;
    final fresh = DateTime.now().difference(availabilityDate).inDays <= freshnessDays;
    if (lastConfirmedAt != null) {
      return fresh ? AvailabilityState.confirmedRecently : AvailabilityState.toReconfirm;
    }
    return fresh ? AvailabilityState.declared : AvailabilityState.toReconfirm;
  }

  /// Statut normalisé : accepte les variantes (pending / approved / rejected…).
  static String _normalizeStatus(dynamic raw) {
    final s = (raw ?? 'approuve').toString().trim().toLowerCase();
    if (s == 'pending' || s == 'en_attente' || s == 'en attente' || s == 'pending_review') return 'en_attente';
    if (s == 'rejected' || s == 'rejete' || s == 'rejeté' || s == 'rejetee' || s == 'rejetée') return 'rejete';
    return 'approuve';
  }

  /// Copie de l'annonce avec un autre statut (modération).
  PropertyModel withStatus(String newStatus) => PropertyModel(
        id: id, titre: titre, description: description, type: type,
        listingType: listingType, categorie: categorie, prix: prix,
        prixParJour: prixParJour, images: images, videoUrl: videoUrl,
        adresse: adresse, proprietaire: proprietaire,
        caracteristiques: caracteristiques, rating: rating, totalAvis: totalAvis,
        isAvailable: isAvailable, isFeatured: isFeatured, createdAt: createdAt,
        vues: vues, surface: surface, nombrePieces: nombrePieces, annee: annee,
        status: newStatus, titreTranslations: titreTranslations,
        descriptionTranslations: descriptionTranslations,
        caracteristiquesTranslations: caracteristiquesTranslations,
        updatedAt: DateTime.now(),
        availabilityStatus: availabilityStatus, lastConfirmedAt: lastConfirmedAt,
        fieldVerified: fieldVerified, fieldVerifiedAt: fieldVerifiedAt,
        fieldVerifiedByName: fieldVerifiedByName,
        verificationRequested: verificationRequested,
      );

  /// Lien de partage vers la page du bien (deep link web)
  // ⚠️ Corrigé : pointait vers "velqix.tg", un domaine jamais configuré —
  // lien mort à chaque partage. Vraie URL Vercel de l'app en attendant un
  // éventuel domaine personnalisé.
  String get shareUrl => 'https://velqix.vercel.app/bien/$id';

  /// Texte de partage incluant le lien retour
  String get shareText {
    final montant = prix % 1 == 0
        ? prix.toInt().toString().replaceAllMapped(
            RegExp(r'(\d)(?=(\d{3})+$)'), (m) => '${m[1]} ')
        : prix.toString();
    return '🏠 $titre\n'
        '📍 ${adresse.full}\n'
        '💰 $montant FCFA\n'
        '🔗 Disponible sur VelQix\n'
        '$shareUrl';
  }

  String get typeLabel => type == PropertyType.immobilier ? 'Immobilier' : 'Mobilier';
  String get listingLabel {
    switch (listingType) {
      case ListingType.vente: return 'Vente';
      case ListingType.location: return 'Location';
      case ListingType.les_deux: return 'Vente / Location';
    }
  }

  String get categorieLabel {
    const labels = {
      PropertyCategory.chambre: 'Chambre',
      PropertyCategory.studio: 'Studio',
      PropertyCategory.localCommercial: 'Local commercial',
      PropertyCategory.maison: 'Maison',
      PropertyCategory.appartement: 'Appartement',
      PropertyCategory.hotel: 'Hôtel',
      PropertyCategory.terrain: 'Terrain',
      PropertyCategory.bureau: 'Bureau',
      PropertyCategory.entrepot: 'Entrepôt',
      PropertyCategory.voiture: 'Voiture',
      PropertyCategory.moto: 'Moto',
      PropertyCategory.camion: 'Camion',
      PropertyCategory.equipement: 'Équipement',
      PropertyCategory.autre: 'Autre',
    };
    return labels[categorie] ?? 'Autre';
  }

  String get firstImage => images.isNotEmpty ? images.first : '';

  factory PropertyModel.fromJson(Map<String, dynamic> json) {
    PropertyType type;
    switch ((json['type'] ?? '').toString().toLowerCase()) {
      case 'mobilier': type = PropertyType.mobilier; break;
      default:         type = PropertyType.immobilier;
    }

    ListingType listingType;
    switch ((json['listingType'] ?? '').toString().toLowerCase()) {
      case 'vente':    listingType = ListingType.vente; break;
      case 'les_deux': listingType = ListingType.les_deux; break;
      case 'location': listingType = ListingType.location; break;
      default:         listingType = ListingType.vente; // défaut Prisma
    }

    PropertyCategory categorie;
    switch ((json['categorie'] ?? '').toString().toLowerCase()) {
      case 'chambre':     categorie = PropertyCategory.chambre; break;
      case 'studio':      categorie = PropertyCategory.studio; break;
      case 'local_commercial':
      case 'localcommercial':
      case 'local':       categorie = PropertyCategory.localCommercial; break;
      case 'maison':      categorie = PropertyCategory.maison; break;
      case 'appartement': categorie = PropertyCategory.appartement; break;
      case 'hotel':       categorie = PropertyCategory.hotel; break;
      case 'terrain':     categorie = PropertyCategory.terrain; break;
      case 'bureau':      categorie = PropertyCategory.bureau; break;
      case 'entrepot':    categorie = PropertyCategory.entrepot; break;
      case 'voiture':     categorie = PropertyCategory.voiture; break;
      case 'moto':        categorie = PropertyCategory.moto; break;
      case 'camion':      categorie = PropertyCategory.camion; break;
      case 'equipement':  categorie = PropertyCategory.equipement; break;
      default:            categorie = PropertyCategory.autre;
    }

    final propJson = json['proprietaire'] as Map<String, dynamic>?;
    final proprietaire = propJson != null
        ? UserModel.fromJson({
            ...propJson,
            'telephone':  propJson['telephone']  ?? '',
            'createdAt':  propJson['createdAt']  ?? DateTime.now().toIso8601String(),
            'prenom':     propJson['prenom']      ?? '',
            'nom':        propJson['nom']         ?? '',
            'email':      propJson['email']       ?? '',
          })
        : UserModel(
            id: '', nom: '', prenom: '', email: '',
            telephone: '', createdAt: DateTime.now(),
          );

    // NOTE : dans le schéma Prisma réel, Property.adresse est une simple String?
    // (jamais un objet imbriqué). L'ancien code tentait un cast `as Map`, qui
    // levait une exception dès qu'une vraie annonce avait une adresse renseignée.
    final adresseRaw = json['adresse'];
    final adresse = adresseRaw is Map<String, dynamic>
        ? AddressModel(
            rue:       adresseRaw['rue']       ?? '',
            ville:     adresseRaw['ville']     ?? json['ville'] ?? '',
            pays:      adresseRaw['pays']      ?? 'Togo',
            latitude:  (adresseRaw['latitude']  as num?)?.toDouble(),
            longitude: (adresseRaw['longitude'] as num?)?.toDouble(),
          )
        : AddressModel(
            rue:   adresseRaw as String? ?? '',
            ville: json['ville'] as String? ?? '',
            pays:  json['pays']  as String? ?? 'Togo',
          );

    return PropertyModel(
      id:              json['id']?.toString() ?? '',
      titre:           json['titre']       ?? '',
      description:     json['description'] ?? '',
      type:            type,
      listingType:     listingType,
      categorie:       categorie,
      prix:            (json['prix'] ?? 0).toDouble(),
      prixParJour:     json['prixParJour']?.toString(),
      images:          (json['images'] as List?)?.cast<String>() ?? [],
      videoUrl:        (json['videoUrl'] as String?)?.trim().isEmpty == true ? null : json['videoUrl'] as String?,
      adresse:         adresse,
      proprietaire:    proprietaire,
      caracteristiques:(json['caracteristiques'] as List?)?.cast<String>() ?? [],
      rating:          (json['rating'] ?? 0.0).toDouble(),
      totalAvis:       json['totalAvis'] ?? 0,
      isAvailable:     json['isAvailable'] ?? true,
      isFeatured:      json['isFeatured']  ?? false,
      createdAt:       json['createdAt'] != null
                           ? DateTime.parse(json['createdAt'])
                           : DateTime.now(),
      vues:            json['vues'] ?? 0,
      // surface est un Float côté Prisma (nombre en JSON)
      surface:         _formatSurface(json['surface']),
      nombrePieces:    (json['nombrePieces'] as num?)?.toInt(),
      annee:           (json['annee'] as num?)?.toInt(),
      status:          _normalizeStatus(json['status'] ?? json['statut']),
      // ⚠️ Corrigé : ces 3 champs existaient dans le modèle et étaient
      // utilisés par getLocalizedTitre/getLocalizedDescription/
      // getLocalizedCaracteristiques, mais n'étaient jamais lus depuis le
      // JSON — les traductions ne s'affichaient donc jamais, quelle que
      // soit la langue de l'utilisateur. Le backend ne renvoie pas encore
      // ces champs aujourd'hui (voir schema.prisma : colonnes ajoutées mais
      // pas encore peuplées), donc les valeurs resteront `null` tant que
      // cette partie backend n'est pas branchée — mais le parsing est
      // maintenant prêt à les recevoir dès qu'elle le sera.
      titreTranslations: (json['titreTranslations'] as Map?)
          ?.map((k, v) => MapEntry(k.toString(), v.toString())),
      descriptionTranslations: (json['descriptionTranslations'] as Map?)
          ?.map((k, v) => MapEntry(k.toString(), v.toString())),
      caracteristiquesTranslations: (json['caracteristiquesTranslations'] as Map?)
          ?.map((k, v) => MapEntry(k.toString(), (v as List).cast<String>())),
      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt'])
          : null,
      availabilityStatus: json['availabilityStatus']?.toString(),
      lastConfirmedAt: json['lastConfirmedAt'] != null
          ? DateTime.tryParse(json['lastConfirmedAt'].toString())
          : null,
      fieldVerified: json['fieldVerified'] == true,
      fieldVerifiedAt: json['fieldVerifiedAt'] != null
          ? DateTime.tryParse(json['fieldVerifiedAt'].toString())
          : null,
      fieldVerifiedByName: json['fieldVerifiedByName']?.toString(),
      verificationRequested: json['verificationRequested'] == true,
    );
  }

  static String? _formatSurface(dynamic raw) {
    if (raw == null) return null;
    if (raw is num) return raw % 1 == 0 ? raw.toInt().toString() : raw.toString();
    return raw.toString();
  }

  /// Returns localized title (falls back to French)
  String getLocalizedTitre(String lang) =>
      titreTranslations?[lang] ?? titreTranslations?['en'] ?? titre;

  /// Returns localized description (falls back to French)
  String getLocalizedDescription(String lang) =>
      descriptionTranslations?[lang] ?? descriptionTranslations?['en'] ?? description;

  /// Returns localized caracteristiques (falls back to French list)
  List<String> getLocalizedCaracteristiques(String lang) =>
      caracteristiquesTranslations?[lang] ?? caracteristiquesTranslations?['en'] ?? caracteristiques;
}

class AddressModel {
  final String rue;
  final String ville;
  final String pays;
  final double? latitude;
  final double? longitude;

  AddressModel({
    required this.rue,
    required this.ville,
    required this.pays,
    this.latitude,
    this.longitude,
  });

  String get full => '$rue, $ville, $pays';
  String get short => '$ville, $pays';
}

enum MessageStatus { sending, sent, delivered, read, failed }
enum MessageType { text, audio, image }

class MessageModel {
  final String id;
  final String senderId;
  final String receiverId;
  final String content;
  final DateTime sentAt;
  final bool isRead;
  final String? propertyId;
  final MessageStatus status;
  final MessageType type;
  // Renseigné uniquement quand type == MessageType.audio.
  // Peut pointer vers un fichier local (pendant l'upload, pour lecture
  // optimiste immédiate) puis être remplacé par l'URL Cloudinary distante.
  final String? audioUrl;
  final int? audioDuration; // secondes
  // Renseigné uniquement quand type == MessageType.image. Idem : peut être
  // une data URI locale pendant l'upload, puis l'URL Cloudinary distante.
  final String? imageUrl;

  MessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.content,
    required this.sentAt,
    this.isRead = false,
    this.propertyId,
    this.status = MessageStatus.sent,
    this.type = MessageType.text,
    this.audioUrl,
    this.audioDuration,
    this.imageUrl,
  });

  /// Alias pour le code qui utilise .text
  String get text => content;
  /// Alias pour le code qui utilise .timestamp
  DateTime get timestamp => sentAt;
  bool get isAudio => type == MessageType.audio;
  bool get isImage => type == MessageType.image;

  MessageModel copyWith({
    String? id,
    MessageStatus? status,
    String? audioUrl,
    int? audioDuration,
    String? imageUrl,
  }) => MessageModel(
    id: id ?? this.id,
    senderId: senderId,
    receiverId: receiverId,
    content: content,
    sentAt: sentAt,
    isRead: isRead,
    propertyId: propertyId,
    status: status ?? this.status,
    type: type,
    audioUrl: audioUrl ?? this.audioUrl,
    audioDuration: audioDuration ?? this.audioDuration,
    imageUrl: imageUrl ?? this.imageUrl,
  );

  factory MessageModel.fromJson(Map<String, dynamic> json) => MessageModel(
    id:         json['id'] ?? '',
    senderId:   json['senderId'] ?? '',
    receiverId: json['receiverId'] ?? '',
    content:    json['text'] ?? json['content'] ?? '',
    sentAt:     DateTime.tryParse(
          (json['timestamp'] ?? json['createdAt'] ?? json['sentAt'] ?? '').toString(),
        )?.toLocal() ?? DateTime.now(),
    isRead:     json['isRead'] ?? false,
    propertyId: json['propertyId'],
    type:       json['type'] == 'audio'
        ? MessageType.audio
        : json['type'] == 'image'
            ? MessageType.image
            : MessageType.text,
    audioUrl:   json['audioUrl'],
    audioDuration: json['audioDuration'],
    imageUrl:   json['imageUrl'],
  );
}

class AvisModel {
  final String id;
  final UserModel auteur;
  final String cible; // propertyId or userId
  final double note;
  final String commentaire;
  final DateTime createdAt;

  AvisModel({
    required this.id,
    required this.auteur,
    required this.cible,
    required this.note,
    required this.commentaire,
    required this.createdAt,
  });
}