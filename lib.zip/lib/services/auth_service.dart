import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../widgets/widgets.dart';
import '../models/models.dart';
import 'mock_data.dart';

/// Clés de stockage
const _kUsername   = 'auth_username';
const _kPassword   = 'auth_password';
const _kLoggedIn   = 'auth_logged_in';
const _kNom        = 'auth_nom';
const _kPrenom     = 'auth_prenom';
const _kEmail      = 'auth_email';
const _kTelephone  = 'auth_telephone';
const _kUserId     = 'auth_user_id';
const _kIsPremium  = 'auth_is_premium';
const _kIsVerified = 'auth_is_verified';
const _kRole       = 'auth_role';
const _kCreatedAt  = 'auth_created_at';
const _kAuthMethod = 'auth_method'; // 'email' | 'google' | 'facebook'
const _kCountryCode = 'auth_country_code';
const _kCountryName = 'auth_country_name';

// ── Google Sign-In ────────────────────────────────────────────────────────────
final _googleSignIn = GoogleSignIn(
  clientId: '465274402627-7qtn4rava253u4qh0gbr6bv74pu9ieqm.apps.googleusercontent.com',
  scopes: ['email', 'profile'],
);

class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  UserModel? _loggedUser;
  String?    _loggedUsername;
  String?    _registeredPassword;

  bool   get isLoggedIn     => _loggedUsername != null;
  String get loggedUsername => _loggedUsername ?? '';
  UserModel get currentUser => _loggedUser ?? MockDataService.currentUser;

  // ─── Auto-login au démarrage ────────────────────────────────────────────────
  Future<bool> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final loggedIn = prefs.getBool(_kLoggedIn) ?? false;
    if (!loggedIn) return false;
    final username = prefs.getString(_kUsername);
    if (username == null) return false;

    _loggedUsername     = username;
    _registeredPassword = prefs.getString(_kPassword);
    _loggedUser = UserModel(
      id:         prefs.getString(_kUserId)    ?? 'user_local',
      nom:        prefs.getString(_kNom)       ?? username,
      prenom:     prefs.getString(_kPrenom)    ?? '',
      email:      prefs.getString(_kEmail)     ?? '$username@innorent.tg',
      telephone:  prefs.getString(_kTelephone) ?? '',
      isVerified: prefs.getBool(_kIsVerified)  ?? false,
      isPremium:  prefs.getBool(_kIsPremium)   ?? false,
      rating:     0,
      totalAvis:  0,
      createdAt:  DateTime.tryParse(prefs.getString(_kCreatedAt) ?? '') ?? DateTime.now(),
      role:       prefs.getString(_kRole) ?? 'proprietaire',
      countryCode: prefs.getString(_kCountryCode),
      countryName: prefs.getString(_kCountryName),
    );
    return true;
  }

  // ─── Inscription email ──────────────────────────────────────────────────────
  Future<void> register({
    required String username,
    required String password,
    String? nom,
    String? prenom,
    String? email,
    String? telephone,
    String? countryCode,
    String? countryName,
    String accountType = 'personal',
    String? nomEntreprise,
    String? typeActivite,
  }) async {
    final userId = 'user_\${DateTime.now().millisecondsSinceEpoch}';
    _loggedUsername     = username.trim().toLowerCase();
    _registeredPassword = password;
    _loggedUser = UserModel(
      id:        userId,
      nom:       nom    ?? username,
      prenom:    prenom ?? '',
      email:     email  ?? '\$username@innorent.tg',
      telephone: telephone ?? '',
      isVerified: false, isPremium: false,
      rating: 0, totalAvis: 0,
      createdAt: DateTime.now(), role: 'proprietaire',
      countryCode: countryCode,
      countryName: countryName,
      accountType: accountType,
      nomEntreprise: nomEntreprise,
      typeActivite: typeActivite,
    );
    await _persist(password: password, method: 'email');
  }

  // ─── Connexion email ────────────────────────────────────────────────────────
  Future<String?> login({required String username, required String password}) async {
    // ✅ Compte admin hardcodé (username: admin, password: admin1234)
    if (username.trim().toLowerCase() == 'admin' && password == 'admin1234') {
      final admin = MockDataService.adminUser;
      _loggedUsername = 'admin';
      _loggedUser = admin;
      // ✅ Persister le compte admin complet pour éviter des états corrompus
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_kLoggedIn,   true);
      await prefs.setString(_kUsername,  'admin');
      await prefs.setString(_kPassword,  'admin1234');
      await prefs.setString(_kUserId,    admin.id);
      await prefs.setString(_kNom,       admin.nom);
      await prefs.setString(_kPrenom,    admin.prenom);
      await prefs.setString(_kEmail,     admin.email);
      await prefs.setString(_kTelephone, admin.telephone ?? '');
      await prefs.setBool(_kIsPremium,   admin.isPremium);
      await prefs.setBool(_kIsVerified,  admin.isVerified);
      await prefs.setString(_kRole,      'admin');
      await prefs.setString(_kCreatedAt, admin.createdAt.toIso8601String());
      await prefs.setString(_kAuthMethod,'email');
      return null;
    }

    final prefs = await SharedPreferences.getInstance();
    final saved    = prefs.getString(_kUsername);
    final savedPwd = prefs.getString(_kPassword);

    if (saved == null) return 'Aucun compte trouvé. Veuillez d\'abord vous inscrire.';
    if (username.trim().toLowerCase() != saved) return 'Nom d\'utilisateur introuvable.';
    if (password != savedPwd) return 'Mot de passe incorrect.';

    _loggedUsername     = username.trim();
    _registeredPassword = savedPwd;
    _loggedUser = UserModel(
      id:         prefs.getString(_kUserId)    ?? 'user_local',
      nom:        prefs.getString(_kNom)       ?? username,
      prenom:     prefs.getString(_kPrenom)    ?? '',
      email:      prefs.getString(_kEmail)     ?? '$username@innorent.tg',
      telephone:  prefs.getString(_kTelephone) ?? '',
      isVerified: prefs.getBool(_kIsVerified)  ?? false,
      isPremium:  prefs.getBool(_kIsPremium)   ?? false,
      rating: 0, totalAvis: 0,
      createdAt:  DateTime.tryParse(prefs.getString(_kCreatedAt) ?? '') ?? DateTime.now(),
      role:       prefs.getString(_kRole) ?? 'proprietaire',
      // ✅ CORRECTIF Bug 1 : restaurer countryCode/countryName au login
      // Sans ça, currentUser.countryCode = null → locale reste 'fr' pour tout le monde
      countryCode: prefs.getString(_kCountryCode),
      countryName: prefs.getString(_kCountryName),
    );
    await prefs.setBool(_kLoggedIn, true);
    return null;
  }

  // ─── Connexion Google ───────────────────────────────────────────────────────
  Future<String?> loginWithGoogle() async {
    try {
      GoogleSignInAccount? account;

      // 1. Essayer la reconnexion silencieuse (session existante)
      try { account = await _googleSignIn.signInSilently(); } catch (_) {}

      // 2. Si pas de session → popup (Android et Web)
      if (account == null) {
        try {
          account = await _googleSignIn.signIn();
        } catch (e) {
          final msg = e.toString().toLowerCase();
          if (msg.contains('cancel') || msg.contains('annul') || msg.contains('dismiss')) {
            return 'Connexion Google annulée.';
          }
          rethrow;
        }
      }

      // 3. Sur web uniquement, signIn() peut retourner null → vérifier currentUser
      if (account == null) {
        account = _googleSignIn.currentUser;
      }

      if (account == null) return 'Connexion Google annulée.';

      final names = account.displayName?.split(' ') ?? ['', ''];
      final prenom = names.isNotEmpty ? names.first : '';
      final nom    = names.length > 1 ? names.sublist(1).join(' ') : '';

      _loggedUsername = account.email;
      _loggedUser = UserModel(
        id:         'google_${account.id}',
        nom:        nom.isEmpty ? account.email.split('@').first : nom,
        prenom:     prenom,
        email:      account.email,
        telephone:  '',
        avatarUrl:  account.photoUrl,
        isVerified: true,  // compte Google = vérifié
        isPremium:  false,
        rating:     0, totalAvis: 0,
        createdAt:  DateTime.now(), role: 'proprietaire',
      );

      await _persistSocial(method: 'google');
      notifyUserChanged();
      return null; // succès
    } catch (e) {
      // Si malgré l'exception l'utilisateur est connecté → succès
      if (_loggedUser != null) return null;
      final msg = e.toString();
      if (msg.contains('popup_closed') || msg.contains('user_cancel') ||
          msg.contains('canceled') || msg.contains('annul')) {
        return 'Connexion Google annulée.';
      }
      // Toutes les autres erreurs Google (gapi, FedCM, etc.) → ignorer
      return null;
    }
  }

  // ─── Connexion Facebook ─────────────────────────────────────────────────────
  Future<String?> loginWithFacebook() async {
    try {
      // flutter_facebook_auth
      final result = await FacebookAuth.instance.login(permissions: ['email', 'public_profile']);
      if (result.status != LoginStatus.success) return 'Connexion Facebook annulée.';

      final data = await FacebookAuth.instance.getUserData(fields: 'name,email,picture.width(200)');
      final fullName = data['name'] as String? ?? '';
      final names  = fullName.split(' ');
      final prenom = names.isNotEmpty ? names.first : '';
      final nom    = names.length > 1 ? names.sublist(1).join(' ') : fullName;
      final email  = data['email'] as String? ?? 'facebook_user@velqix.tg';
      final avatar = (data['picture']?['data']?['url']) as String?;

      _loggedUsername = email;
      _loggedUser = UserModel(
        id:         'fb_${data['id'] ?? DateTime.now().millisecondsSinceEpoch}',
        nom:        nom,
        prenom:     prenom,
        email:      email,
        telephone:  '',
        avatarUrl:  avatar,
        isVerified: true,
        isPremium:  false,
        rating: 0, totalAvis: 0,
        createdAt: DateTime.now(), role: 'proprietaire',
      );

      await _persistSocial(method: 'facebook');
      notifyUserChanged();
      return null;
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('not supported') || msg.contains('web') ||
          msg.contains('MissingPluginException') || msg.contains('PlatformException')) {
        return "Facebook Login non disponible sur le web. Utilisez l'app mobile.";
      }
      return 'Erreur Facebook Login : $e';
    }
  }

  // ─── Déconnexion ────────────────────────────────────────────────────────────
  Future<void> logout() async {
    // Déconnexion Google si connecté via Google
    try {
      if (await _googleSignIn.isSignedIn()) {
        await _googleSignIn.signOut();
      }
    } catch (_) {}

    _loggedUsername = null;
    _loggedUser     = null;
    _registeredPassword = null;

    // ✅ On ferme uniquement la SESSION — les données du compte (username,
    // password, nom, email…) restent persistées pour permettre la reconnexion.
    // Seul _kLoggedIn passe à false pour bloquer l'auto-login.
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kLoggedIn, false);

    // ✅ Ne PAS réinitialiser pendingPropertiesNotifier ni publishedPropertiesNotifier
    // Les annonces soumises doivent rester visibles à l'admin même après changement de session
    // kycPendingNotifier aussi : les demandes KYC persistent
    notifyUserChanged();
  }

  // ─── Premium ─────────────────────────────────────────────────────────────────
  Future<void> setPremium(bool value) async {
    final base = _loggedUser ?? MockDataService.currentUser;
    _loggedUser = UserModel(
      id: base.id, nom: base.nom, prenom: base.prenom,
      email: base.email, telephone: base.telephone,
      avatarUrl: base.avatarUrl, isVerified: base.isVerified,
      rating: base.rating, totalAvis: base.totalAvis,
      createdAt: base.createdAt, role: base.role, isPremium: value,
    );
    _loggedUsername ??= base.email;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kIsPremium, value);

    // ✅ CORRECTIF : Mettre à jour isFeatured sur toutes les annonces
    // déjà PUBLIÉES appartenant à cet utilisateur.
    // Sans ça, les annonces approuvées AVANT le passage premium
    // restent avec isFeatured:false même après paiement.
    if (value) {
      final updatedOwner = _loggedUser!;
      final updatedPublished = publishedPropertiesNotifier.value.map((item) {
        final p = item as PropertyModel;
        if (p.proprietaire.id != updatedOwner.id) return p;
        // Reconstruire avec isFeatured:true et proprietaire à jour
        return PropertyModel(
          id: p.id, titre: p.titre, description: p.description,
          type: p.type, listingType: p.listingType, categorie: p.categorie,
          prix: p.prix, prixParJour: p.prixParJour, images: p.images,
          adresse: p.adresse, proprietaire: updatedOwner,
          caracteristiques: p.caracteristiques, rating: p.rating,
          totalAvis: p.totalAvis, isAvailable: p.isAvailable,
          isFeatured: true, // ✅ vedette activée immédiatement ⭐
          vues: p.vues, surface: p.surface, nombrePieces: p.nombrePieces,
          annee: p.annee, createdAt: p.createdAt, status: p.status,
        );
      }).toList();
      publishedPropertiesNotifier.value = updatedPublished;
    }

    notifyUserChanged();
  }

  // ─── KYC ────────────────────────────────────────────────────────────────────
  Future<void> setVerified(bool value) async {
    if (_loggedUser == null) return;
    _loggedUser = UserModel(
      id: _loggedUser!.id, nom: _loggedUser!.nom, prenom: _loggedUser!.prenom,
      email: _loggedUser!.email, telephone: _loggedUser!.telephone,
      avatarUrl: _loggedUser!.avatarUrl, isVerified: value,
      rating: _loggedUser!.rating, totalAvis: _loggedUser!.totalAvis,
      createdAt: _loggedUser!.createdAt, role: _loggedUser!.role,
      isPremium: _loggedUser!.isPremium,
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kIsVerified, value);
  }

  // ─── Persistance ────────────────────────────────────────────────────────────
  Future<void> _persist({required String password, required String method}) async {
    final u = _loggedUser!;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kUsername,   _loggedUsername!);
    await prefs.setString(_kPassword,   password);
    await prefs.setBool  (_kLoggedIn,   true);
    await prefs.setString(_kUserId,     u.id);
    await prefs.setString(_kNom,        u.nom);
    await prefs.setString(_kPrenom,     u.prenom);
    await prefs.setString(_kEmail,      u.email);
    await prefs.setString(_kTelephone,  u.telephone ?? '');
    await prefs.setBool  (_kIsPremium,  u.isPremium);
    await prefs.setBool  (_kIsVerified, u.isVerified);
    await prefs.setString(_kRole,       u.role);
    await prefs.setString(_kCreatedAt,  u.createdAt.toIso8601String());
    await prefs.setString(_kAuthMethod, method);
    if (u.countryCode != null) await prefs.setString(_kCountryCode, u.countryCode!);
    if (u.countryName != null) await prefs.setString(_kCountryName, u.countryName!);
  }

  Future<void> _persistSocial({required String method}) async {
    await _persist(password: '', method: method);
  }

  // ─── Mise à jour du profil utilisateur ────────────────────────────────────
  Future<void> updateUser(UserModel updated) async {
    _loggedUser = updated;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kNom, updated.nom);
    await prefs.setString(_kPrenom, updated.prenom);
    await prefs.setString(_kEmail, updated.email);
    await prefs.setString(_kTelephone, updated.telephone ?? '');
    if (updated.countryCode != null) await prefs.setString(_kCountryCode, updated.countryCode!);
    if (updated.countryName != null) await prefs.setString(_kCountryName, updated.countryName!);
  }
  // ─── Changement de mot de passe ─────────────────────────────────────────────
  /// Vérifie [oldPassword], puis sauvegarde [newPassword] en mémoire ET en prefs.
  /// Retourne null si succès, un message d'erreur sinon.
  Future<String?> changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final savedPwd = prefs.getString(_kPassword) ?? '';

    if (oldPassword != savedPwd) return 'Ancien mot de passe incorrect.';

    _registeredPassword = newPassword;
    await prefs.setString(_kPassword, newPassword);
    return null; // succès
  }

}